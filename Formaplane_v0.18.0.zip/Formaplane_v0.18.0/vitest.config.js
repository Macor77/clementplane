import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    globals: true,
    clearMocks: true,
    restoreMocks: true,
    include: [
      'src/**/*.test.{js,jsx}',
      'tests/**/*.test.js',
    ],
  },
});
