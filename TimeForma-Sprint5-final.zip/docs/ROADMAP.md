# ROADMAP - TimeForma

Version : 4.1
Dernière mise à jour : 16/07/2026

---

# Vision

TimeForma a pour ambition de devenir la plateforme de référence permettant aux organismes de formation de :

- gérer leurs formateurs ;
- planifier leurs missions ;
- automatiser les affectations ;
- collaborer avec leurs formateurs ;
- développer leur réseau.

Le développement suit une règle simple :

> Construire d'abord un excellent outil interne, puis le transformer progressivement en plateforme SaaS.

---

# État actuel

## Sprint 1 — MVP ✅

- Gestion des fiches formateurs
- CRUD complet
- Import CSV
- Carte Leaflet

---

## Sprint 2 — Migration Supabase ✅

- Migration PostgreSQL
- Synchronisation Supabase
- Architecture Services
- Déploiement Vercel

---

## Sprint 3 — Disponibilités ✅

- Calendrier individuel
- Gestion des disponibilités
- Notes multiples
- Dernière mise à jour

---

## Sprint 4 — Planning mensuel ✅

- Planning intégré au listing
- Navigation entre les mois
- Optimisation des requêtes
- Chargement d'un mois complet

---

## Sprint 4.5 — Refactoring ✅

- Découpage de ListingTable
- Hooks spécialisés
- Components Planning
- Simplification de l'architecture

---

## Sprint 5 — Recherche & Géolocalisation ✅

### Recherche

- Recherche multicritères
- Tri des colonnes
- Calcul des distances
- Recherche géographique
- Tri automatique par distance

### Géolocalisation

- Géocodage via Edge Function
- Complétion automatique des coordonnées GPS
- Affichage du lieu reconnu
- Affichage du département
- Affichage du code postal

### Technique

- Architecture Hooks / Services stabilisée
- Déploiement Supabase Edge Functions
- Documentation complète

---

# Sprint 6 — Moteur de missions

## Objectif

Faire de la mission le cœur de TimeForma.

À la fin de ce sprint, Alter Prévention devra pouvoir gérer l'ensemble de ses missions directement depuis TimeForma.

Une mission est indépendante des formateurs.

Elle peut être créée, enregistrée et modifiée sans qu'aucun formateur ne soit encore affecté.

Les formateurs seront ensuite liés à la mission selon le processus suivant :

```text
Sélection
↓
Proposition envoyée
↓
Acceptation ou refus
↓
Affectation
```

---

## Gestion des missions

- Création d'une mission
- Modification d'une mission
- Suppression
- Consultation
- Duplication

---

## Informations d'une mission

Les seules informations obligatoires sont :

- le lieu ;
- au moins une date.

Les autres informations restent facultatives.

Une mission peut notamment contenir :

- Nom de la mission
- Code interne
- Nom de la formation
- Lieu
- Une ou plusieurs dates
- Horaires
- Compétences nécessaires
- Matériel nécessaire
- Prix de vente
- Coût formateur
- Commentaire libre

---

## Gestion des dates

Une mission peut contenir plusieurs journées distinctes.

Exemple :

- Lundi 5 octobre
- Lundi 12 octobre
- Jeudi 15 octobre

Chaque journée peut posséder ses propres horaires.

---

## Statut de la mission

- Brouillon
- À pourvoir
- Affectée
- Confirmée
- Réalisée
- Annulée
- Archivée

---

## Recherche des formateurs

Pendant la création ou la modification d'une mission, TimeForma propose automatiquement les meilleurs profils.

Les propositions sont filtrées selon :

- les compétences requises ;
- le matériel requis.

Les formateurs sont ensuite classés du plus proche au plus éloigné grâce au calcul des distances.

---

## Disponibilités

La disponibilité ne masque jamais un formateur.

Elle est indiquée visuellement :

- 🟢 Disponible
- 🔴 Indisponible
- ⚪ Planning non renseigné
- 🟠 Déjà en mission

---

## Gestion des propositions

Une mission peut être proposée à plusieurs formateurs.

Chaque formateur possède son propre statut :

- Sélectionné
- Proposition envoyée
- Acceptée
- Refusée
- Affecté

Le logiciel conserve l'historique des propositions et des réponses.

---

## Affectation

Lorsqu'un formateur est affecté :

- le planning est mis à jour automatiquement ;
- les conflits sont détectés ;
- les doubles affectations sont empêchées ;
- la mission passe automatiquement au statut "Affectée".

Aucun compte formateur n'est nécessaire pour ce sprint.

---

# Sprint 7 — Comptes Formateurs

## Objectif

Rendre les formateurs autonomes.

---

## Authentification

- Connexion
- Déconnexion
- Mot de passe oublié
- Revendication d'une fiche

---

## Profil

Le formateur pourra modifier :

- coordonnées
- compétences
- matériel
- tarif
- adresse

---

## Disponibilités

- Gestion du calendrier
- Ajout de notes
- Mise à jour des disponibilités

---

## Préférences

- Rayon d'intervention
- Distance maximale
- Types de formations souhaitées
- Tarif minimum accepté

---

Le logiciel continuera à fonctionner même si certains formateurs ne disposent pas encore d'un compte.

---

# Sprint 8 — Proposition des missions

## Objectif

Automatiser progressivement la mise en relation.

---

## Sélection automatique

À partir d'une mission, TimeForma proposera automatiquement les meilleurs profils.

Critères :

- compétences
- disponibilité
- distance
- matériel
- préférences
- coût

---

## Proposition

Le planificateur pourra envoyer une proposition à plusieurs formateurs.

Exemples :

- 3 formateurs
- 5 formateurs
- 10 formateurs

---

## Réponse

Le formateur recevra une notification.

Il pourra :

- accepter
- refuser

---

## Affectation

Le premier ayant accepté pourra être automatiquement affecté.

Le planning sera réservé automatiquement.

Les autres propositions seront annulées.

---

## Historique

Le logiciel conservera :

- les propositions envoyées
- les réponses
- les délais de réponse
- le formateur retenu

---

# Sprint 9 — Marketplace

## Objectif

Faire de TimeForma une plateforme collaborative.

---

- Publication de missions
- Recherche de formateurs
- Réseau de formateurs
- Invitations
- Référencement
- Notation
- Historique des collaborations

---

# Sprint 10 — SaaS

## Objectif

Ouvrir TimeForma à plusieurs organismes.

---

## Multi-organismes

- Isolation des données
- Gestion des utilisateurs
- Gestion des rôles

---

## Administration

- Tableau de bord
- Paramétrage
- Statistiques

---

## Commercialisation

- Abonnements
- Paiements
- Facturation
- Gestion des licences

---

# Sprint 11 — Pilotage

## Objectif

Donner aux dirigeants une vision complète de leur activité.

---

- Tableau de bord
- CA par client
- CA par formateur
- Marge par mission
- Missions réalisées
- Taux d'acceptation
- Temps moyen d'affectation
- Kilomètres parcourus
- Taux de remplissage
- Export Excel / PDF

---

# Idées futures

## Intelligence artificielle

- Suggestion automatique du meilleur formateur
- Optimisation des tournées
- Prévision des disponibilités
- Détection d'anomalies
- Assistant de planification

---

## Mobilité

- Application mobile
- Notifications Push
- Signature électronique

---

## Documents

- Convention
- Convocation
- Feuille de présence
- Attestation
- Certificat

---

# Philosophie

Chaque sprint doit produire une fonctionnalité immédiatement utile à Alter Prévention.

La priorité reste toujours :

1. Simplicité.
2. Valeur métier.
3. Évolutivité.
4. Qualité du code.
5. Expérience utilisateur.